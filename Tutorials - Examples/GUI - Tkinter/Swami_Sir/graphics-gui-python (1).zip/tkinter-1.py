import tkinter
top = tkinter.Tk()
# Code to add widgets...
top.mainloop()
